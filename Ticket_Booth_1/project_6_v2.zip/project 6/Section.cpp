#include "Section.h"
using namespace std;

Section::Section(string SectionName):
section_name(SectionName),  rowCount(0), totalSeats(0)
{}

void Section::addToSec(string name,int row_start,int row_end)
{
    SecRow s={name,row_start,row_end};
    *section_rows[rowCount++]=s;
    totalSeats+=(s.row_end-s.row_start);


}

//function displays row names and ranges per section
void Section::Display() const {

cout << "Section: " << section_name << endl;
   for(int i = 0; i < rowCount; i++){
	cout << "Row " << section_rows[i]<< " Seats " << section_rows[i]->row_start << " - " << section_rows[i]->row_end <<  endl;
   }

}

Section::~Section(void){}
