#include <iostream>
#include <string>
#include <cassert>
#include "Venue.h"
#include "Seat_Row.h"
#include "Seat.h"
#include "Address.h"

using namespace std;

Venue* addVenue();
void inputseatrow(Venue* venue);
void Add_Section(Venue* venue);

int main() {
	int funcsel = 0;
	int venue_count = 0;
	Venue* venue_[100];

	cout << "Logged in as System Administrator" << endl;

	while (true) {
		cout << "To add a venue enter \"1\". To exit, enter -1." << endl;
		cin >> funcsel;

		cin.ignore(INT_MAX, '\n');

		switch (funcsel) {
		case 1:
			venue_[venue_count] = addVenue();
			Add_Section(venue_[venue_count]);
			venue_[venue_count]->DisplayAll();
			venue_count++;
			break;
		case -1:
			return 0;
			break;
		default:
			cout << "Invalid input. Please try again." << endl;
		}
	}
}

Venue* addVenue() {
	string name, street, city, state;

	int zip;

	cout << "Enter the name of the venue: ";
	getline(cin,name);
	cout << "Street Address: ";
	getline(cin, street);
	cout << "City: ";
	getline(cin, city);
	cout << "State: ";
	getline(cin, state);
	cout << "Zip: ";
	cin >> zip;
	cin.ignore(INT_MAX, '\n');
	cout << endl;

	Address *address_ = new Address(street, city, state, zip);

	Venue* venue_ = new Venue(name, address_);

	inputseatrow(venue_);

	return venue_;
}

void inputseatrow(Venue* venue) {
	string space = " ";
	string check;
	string row_name;
	int num_seats;
	int i = 0;
	int j;

	Seat_Row* seat_row[100];
	Seat* seat;

	cout << "Enter seat row information\nEnter blank line for name when finished" << endl;

	do {

		cout << "Row Name: ";
		getline(cin,row_name);
		if (!row_name.empty()) {
			cout << "Number of Seats: ";
			cin >> num_seats;
			cin.ignore(INT_MAX, '\n');
			j = 0;
			seat_row[i] = new Seat_Row(row_name);

			while (j < num_seats) {
				seat = new Seat(++j);
				seat_row[i]->Add_Seat(seat);
			}

			venue->Add_Seat_Row(seat_row[i]);

			i++;

		}
		else {
			break;
		}

	} while (i < 1000);
}

void Add_Section(Venue* venue) {
	const int MAX_ROWS = 100;

	string row_name;
	int row_begin;
	int row_stop;
	int ctr = 0;
	string name;
	static int sec_num = 0;
	static Section *sec[100];

	cout << "\nEnter seation section information\nEnter blank line for name when finished"<< endl;

	do {
		cout << "Section: ";
		getline(cin, name);
		if (!name.empty()) {

			do {
				cout << "Row name: ";
				getline(cin, row_name);
				if (row_name.empty()) {
					break;
				}
				else {

					cout << "First seat number: ";
					cin >> row_begin;
					cout << "Last row number: ";
					cin >> row_stop;

					//sec[sec_num]->
					Section *sec1 = new Section(name);
					sec1->addToSec(row_name, row_begin, row_stop);
					venue->Add_Section(sec1);
				}
				ctr++;
				cin.ignore(INT_MAX, '\n');
			} while (ctr < 100);

		}
		else {
			break;
		}
	} while (ctr < 100);
}