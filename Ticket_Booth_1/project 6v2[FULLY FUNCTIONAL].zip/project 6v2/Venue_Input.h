#ifndef VENUE_INPUT_H_INCLUDED
#define VENUE_INPUT_H_INCLUDED
#include "Venue.h"

class Venue_Input
{
public:
    static void addRows(Venue* ven);
    static void addSection(Venue* ven);

    static Venue* getVenue(Venue* ven);

}

#endif // VENUE_INPUT_H_INCLUDED
