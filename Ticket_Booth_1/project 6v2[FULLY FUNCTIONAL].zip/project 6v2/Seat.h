//need section class

#pragma once
#include <string>
using namespace std;

class Seat
{    
    
private:
    int seat_number;
    
public:
    Seat(int Seat_Number);
    
    void Display() const;
};
