#pragma once
#include <iostream>
#include <string>

using namespace std;

class Section{

	private:
    string section_name;

	struct SecRow{
	string row_name;
	int row_start;		//int for row start
	int row_end; //row range end 
	};

	int rowCount;
	int totalSeats;
	SecRow* section_rows [100];		// number of rows in section

	public:
	Section(){};
	Section(string SectionName);
	string Get_Name() const { return section_name; };
	void addToSec(string name,int row_start,int row_end);
	void Display() const;

	~Section();


};
