#pragma once
#include "tinyxml.h"
#include "Address.h"
#include "Venue.h"
#include "Seat_Row.h"
#include "Seat.h"
static class Venue_from_Xml
{
public:
    static Venue* Get_Venue(TiXmlNode* venue_node);

private:
    static Address* Get_Address(TiXmlNode* address_node);

    static Seat_Row* Get_Seat_Row(TiXmlNode* seat_row_node,string rowName);
    static void Get_Seats(TiXmlNode* seat_row_node, Venue* ven);
    static Seat* Get_Seat(TiXmlNode* seat_node, string rowName,Seat_Row* row );
};

