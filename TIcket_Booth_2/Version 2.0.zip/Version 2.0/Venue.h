#pragma once
#include <string.h>
#include "Address.h"
#include "Seat.h"
#include "Seat_Row.h"
#include "Section.h"

using std::string;

class Venue
{
public:
    static const int MAX_VENUE_NAME = 40;
    static const int MAX_SEAT_ROWS = 1000;
    static const int MAX_SECTIONS = 1000;

private:
    string name;
    Address address;

    int number_of_seat_rows;
	int number_of_sections;

    Section* sections[MAX_SECTIONS];
	Seat_Row* seat_row[MAX_SEAT_ROWS];
    
public:
    Venue(const string& Name, 
          const Address& Address);
    Venue() {};

	void Add_Row(Seat_Row* sr1);


    void Add_Section(Section* new_sections);


    int Capacity() const;     // Number of seats

    const Seat_Row* Get_Seat_Row(int index) const 
        {return seat_row[index];};

    int Get_Number_of_Seat_Rows() const 
        {return number_of_seat_rows;};


    const Section* Get__Section(int index) const 
        {return sections[index];};

    int Get_Number_of_Sections() const 
        {return number_of_sections;};


    void Display() const;
    void Display_All() const;

    string Name() const {return name;};

    bool operator<(const Venue& other) const;
};
