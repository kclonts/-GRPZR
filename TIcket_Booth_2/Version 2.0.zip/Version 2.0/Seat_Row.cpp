#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string.h>
#include <cassert>
#include "Seat_Row.h"

using namespace std;
/*seat row constructor ---*/
//Seat_Row::Seat_Row(const string& Row_Name,
//                   int Number_of_Seats) :
//                   row_name(Row_Name), number_of_seats(Number_of_Seats)
//{
//  //  seats = new Seat*[number_of_seats];
//    for (int i = 0; i < number_of_seats; ++i)
//    {
//        seats[i] = new Seat(Row_Name, i+1, "what goes here");
//    }
//}

Seat_Row::Seat_Row(const string& Row_name) :
	row_name(Row_name), number_of_seats(0) {}

void Seat_Row::Add_Seat(Seat* s1)
{
	seats[number_of_seats++] = s1;
}

void Seat_Row::Add_Seat(const string& Row_Name, int& num_seats)
{
	number_of_seats = num_seats;
	assert(num_seats < MAX_SEATS_PER_ROW);
	assert(num_seats >= MAX_SEATS_PER_ROW);
	Seat *s = new Seat(Row_Name, num_seats);
	seats[number_of_seats++] = s;
}

const Seat* Seat_Row::Get_Seat(int idx) const
{
    if ((idx < 0) || (idx >= number_of_seats))
    {
        throw "Invalid idx argument passed to Get_Seat";
    }
    return seats[idx];
}

void Seat_Row::Display() const
{
    cout << "Row " << row_name << " Seats  1 - " 
         << number_of_seats << endl;
}

