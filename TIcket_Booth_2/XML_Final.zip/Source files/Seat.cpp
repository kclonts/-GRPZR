#include <iostream>
#include <string.h>

#include "Seat.h"
using namespace std;

Seat::Seat (const string& Row_Name, int Seat_Number, Section* Section_) :
	seat_row_name(Row_Name),
	seat_number(Seat_Number),
	section(Section_)
{}

/*overload for seat_row seat creation*/
Seat::Seat(const string& Row_Name, int Seat_Number) :
	seat_row_name(Row_Name),
	seat_number(Seat_Number) 
{}

void Seat::Input_Section(Section* sec) {
	if (this->section_->Get_Name != "NULL") cout << 
}

void Seat::Display() const
{
    cout << "Row " << seat_row_name << " Seat " << seat_number << " Section " << section_;
}
