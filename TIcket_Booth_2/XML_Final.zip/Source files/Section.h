#pragma once
#include <string>
#include "Seat.h"
using std::string;

const int MAX_SECTIONS = 1000;
const int MAX_ROW_SEATS = 1000;

class Section
{
private:
    struct Section_item							/*section struct item definition*/
    {
        string row_name;
        int first_seat_number;
        int last_seat_number;
    };

public:
    Section(string name);
	void Add_Section(string& row_name, int& seat_number);

    string Get_Name() const {return name;};		/*get section name*/
    int Get_Number_of_Elements() const {return number_of_elements;};	/*get number of sections*/

    void get_section(int i,							/*get section name and range*/
                      string& name, 
                      int& first_seat_number, 
                      int& last_seat_number) const;

	void Add_A_Seat(Seat* s);


    void Display() const;
    string name;

private:
	/*section item attributes*/
    Section_item sections[MAX_SECTIONS];		/*collection of rows and ranges*/
	int number_of_elements;						/*number of different rows and ranges*/
	Seat* section_seats[MAX_SECTIONS];			/*seat objects in section*/
	int number_of_seats;					/*number of seats per section*/
	
};
