#pragma once
#include <string>
#include "Section.h"
using namespace std;

class Seat
{
    
private:
    Section* section_;
    string seat_row_name;
    int seat_number;
    
public:
    Seat(const string& Row_Name, int Seat_Number, Section* Section_);
	//Seat(const string& Row_Name, int Seat_Number);
	Section* Get_Section() const { return section_; };
	void Input_Section(Section* sec);
    
    void Display() const;
};


