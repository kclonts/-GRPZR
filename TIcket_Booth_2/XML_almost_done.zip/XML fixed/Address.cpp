#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <string.h>
#include "Address.h"
#include <iomanip>

using namespace std;

Address::Address(const string& Street_Address,
            const string& City,
            const string& State,
            int Zip_Code) : 
   street_address(Street_Address), city(City), state(State), zip_code(Zip_Code)
{}


void Address::Display() const
{
    cout << street_address << endl;
    cout << city << ", " << state << " ";
    cout << setw(5)<< setfill('0')<< zip_code << endl;
}

