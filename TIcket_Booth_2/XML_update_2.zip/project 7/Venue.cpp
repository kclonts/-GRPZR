#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string>
#include "Venue.h"

using namespace std;
/*purpose: venue constructor
  parameters: name, address
*/
Venue::Venue(const string& Name, 
             const Address& Address) :
    name(Name), address(Address), number_of_seat_rows(0),
    number_of_sections(0)
{}

void Venue::Add_Row(Seat_Row* sr1)
{
    if (number_of_seat_rows >= MAX_SEAT_ROWS)
    {
        throw "Venue error: too many seat rows\n";
    }

	seat_row[number_of_seat_rows++] = sr1;		//add new row to collection of seat rows


}

void Venue::Add_Section(Section* new_section)
{
    if (number_of_sections >= MAX_SECTIONS)
    {
        throw "Venue error: too many seating sections\n";
    }
	 sections[number_of_sections++] = new_section;
}

void Venue::Create_from_seats(Seat* s)
{
    bool section_exists=false;
    if(number_of_sections==0)
    {
        sections[number_of_sections]=new Section(s->Get_Section());
        sections[number_of_sections++]->Add_A_Seat(s);
    }
    
    else
    {
        for(int i=0;i<number_of_sections;i++)
        {
            if(sections[i]->name==s->Get_Section())
            {
                section_exists=true;
                sections[i]->Add_A_Seat(s);
            }
        }
        
        if(section_exists==false)
        {
            sections[++number_of_sections]=new Section(s->Get_Section());
            sections[number_of_sections]->Add_A_Seat(s);
        }
        
    }
}

void Venue::Section_from_rows()
{
    for(int i=0;i<number_of_seat_rows;i++)
    {
        for(int j=0;j<seat_row[i]->Number_of_Seats();j++)
        {
            Create_from_seats(seat_row[i]->Get_Seat(j));
        }
    }
}

// Return number of seats
int Venue::Capacity() const
{
    int count = 0;
    for (int i = 0; i < number_of_seat_rows; ++i)
    {
        count += seat_row[i]->Number_of_Seats();
    }
    return count;
}

void Venue::Display() const
{
    cout << name << endl;
    address.Display();
}

void Venue::Display_All() const
{
    Display();  
    for (int i = 0; i < number_of_seat_rows; ++i)
    {

		seat_row[i]->Display();
    }

    for (int i = 0; i < number_of_sections; ++i)
    {
        sections[i]->Display();
    }
    
}


bool Venue::operator<(const Venue& other) const
{
    if (this->address.Zip_Code() < other.address.Zip_Code())
    {
        return true;
    }

    if (this->address.Zip_Code() > other.address.Zip_Code())
    {
        return false;
    }

    // Zip Codes are equal.
    return this->name < other.name;
}
