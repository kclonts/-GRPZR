#include <iostream>
#include <cassert>
#include <string>
#include "tinyxml.h"
#include "Venue_from_Xml.h"

using namespace std;
int main()
{
    
    string filename = "Venue.xml";
    TiXmlDocument doc(filename);
    
    bool loadOkay = doc.LoadFile();
    if (!loadOkay)
    {
        cout << "Could not load file " << filename << endl;
        cout << "Error='" << doc.ErrorDesc() << "'. Exiting.\n";
        cin.get();
        exit(1);
    }
    
    TiXmlNode* venue_file_node = doc.FirstChild("venue_file");
    assert(venue_file_node != 0);
    
    
    TiXmlNode* venue_node = venue_file_node->FirstChild();
    assert(venue_node != 0);
    Venue* v;
    
    v=Venue_from_Xml::Get_Venue(venue_node);
    v->Display_All();
    
    cin.get();
    return 0;
}
