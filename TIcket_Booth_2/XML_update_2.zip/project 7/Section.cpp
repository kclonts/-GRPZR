#include <iostream>
#include <cassert>
#include "Section.h"

using namespace std;
Section::Section(string Name) :				/*section instantiated with name only*/
  name(Name), number_of_seats(0)
{}


/*method to add a new section
Parameters:	name, range
Result: new section created and added to list of sections
*/
void Section::Add_Section(string& row_name, int& seat_number)
{
	//name = name;
	/*add seat objects to collection*/
	//assert(number_of_seats < MAX_ROW_SEATS);
	//section_seats[number_of_seats++] = Add_A_Seat(row_name, seat_number, this->Get_Name());   /*add the seat to the array of seats for the section*/
	//number_of_elements++;

	/*create and store list of ranges*/
    //assert(number_of_elements < MAX_SECTIONS);
	//Section_item sec = { row_name, seat_number, ++number_of_elements };
	//sections[number_of_elements++] = sec;


}
/*Purpose: given an integer parameter, the section and range are assigned to parameter variables*/
void Section::get_section(int i, 
                                  string& name_, 
                                  int& first_seat_number_, 
                                  int& last_seat_number_) const
{
    assert(i >= 0);
    assert(i < number_of_elements);
    name_ = sections[i].row_name;
    first_seat_number_ = sections[i].first_seat_number;
    last_seat_number_ = sections[i].last_seat_number;
}

/*function to add a seat to a collection of seat objects
	Required: row name and number
	Action: object created and stored to array
*/
void Section::Add_A_Seat(Seat* s)
{
	section_seats[number_of_seats++] = s;
}


void Section::Display() const
{
    /*Display seat and section object attributes*/
    for (int i = 0; i < number_of_seats ; ++i)
    {
        section_seats[i]->Display();
    }
    cout << endl;
}
