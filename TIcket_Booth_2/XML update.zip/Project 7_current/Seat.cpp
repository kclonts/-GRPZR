#include <iostream>
#include <string.h>

#include "Seat.h"
//#include "Seat_Row.h"
using namespace std;

Seat::Seat (const string& Row_Name, int Seat_Number, string Section) :
	seat_row_name(Row_Name),
	seat_number(Seat_Number),
	section(Section)
{}

/*overload for seat_row seat creation*/
Seat::Seat(const string& Row_Name, int Seat_Number) :
	seat_row_name(Row_Name),
	seat_number(Seat_Number) 
{}

void Seat::Display() const
{
    cout << "Row " << seat_row_name << " Seat " << seat_number << " Section " << section;
}
