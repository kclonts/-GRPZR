#pragma once
#include <string>
using namespace std;

class Seat
{
    
private:
    string section;
    string seat_row_name;
    int seat_number;
    
public:
    Seat(const string& Row_Name, int Seat_Number, string Section);
	Seat(const string& Row_Name, int Seat_Number);
	string Get_Section() const { return section; };
    
    void Display() const;
};
