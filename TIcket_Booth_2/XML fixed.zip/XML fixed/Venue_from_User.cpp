#include <iostream>
#include <string>
#include "Venue.h"
#include "Venue_from_User.h"
#include "Section.h"

using namespace std;

Venue* Venue_from_User::Get_Venue_from_User()
{
    string name;
    string street_address;
    string city;
    string state;
    int zip_code;

    // Get venue information from user
    cout << "Please enter venue information\n";
    cout << "Name: ";
    getline(cin, name);
    cout << "Street Address: ";
    getline(cin, street_address);
    cout << "City: ";
    getline(cin, city);
    cout << "State: ";
    getline(cin,state);
    cout << "Zip Code: ";
    cin >> zip_code;
    cin.ignore();


    Address adr(street_address, city, state, zip_code);
    Venue* new_venue = new Venue(name, adr);

    Add_Seat_Rows(new_venue);
    Add_Sections(new_venue);
    return new_venue;
}


void Venue_from_User::Add_Seat_Rows(Venue* venue)
{
    cout << "\nEnter seat row information\n";
    cout << "Enter blank line for name when finished\n";
    while (true)
    {
        string seat_row_name;
        string junk;
        int number_of_seats;
        cout << "Seat row name: ";
        getline(cin, seat_row_name);
        if (seat_row_name.length() == 0)
        {
            break;
        }
        cout << "Number of seats: ";
        cin >> number_of_seats;
        getline(cin, junk);
		Seat_Row *seatRow = new Seat_Row();

        venue->Add_Row(seatRow);
    }
}


void Venue_from_User::Add_Sections(Venue* venue)
{
    cout << "\nEnter seating section information\n";
    cout << "Enter blank line for seating section name when finished\n";
    while (true)
    {
        string section_name;
        string junk;
        cout << "Seating Section name: ";
        getline(cin, section_name);
        if (section_name.length() == 0)
        {
            break;
        }
        
       // Section* new_section =   new Section(section_name);
	   Section* new_section =   new Section(section_name);


        cout << "Enter Row names and seat number ranges\n";
        cout << "Enter a blank line for row name when finished with this section\n";

        while (true)
        {
            string row_name;
            int first_seat_number, last_seat_number;
            cout << "Row name: ";
            getline(cin, row_name);
            if (row_name.length() == 0)
            {
                break;
            }
            cout << "First seat number: ";
            cin >> first_seat_number;
            getline(cin, junk);
            cout << "Last seat number: ";
            cin >> last_seat_number;

            getline(cin, junk);

            new_section->Add_Section(row_name, last_seat_number);
            if (new_section->Get_Number_of_Elements() == MAX_SECTIONS)
            {
                break;
            }
        }
        venue->Add_Section(new_section);
        if (venue->Get_Number_of_Sections() == Venue::MAX_SECTIONS)
        {
            break;
        }
    }
}

