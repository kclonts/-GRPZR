#pragma once
#include <string>
#include "Seat.h"

using std::string;

class Seat_Row
{
public:
    static const int MAX_ROW_NAME_LENGTH = 5;
    static const int MAX_SEATS_PER_ROW = 1000;

private:
    string row_name;
    Seat* seats[MAX_SEATS_PER_ROW];					// collection of seat objects
    int number_of_seats;

public:
	Seat_Row(const string& Row_name);

	Seat_Row() {};						//initializing empty seat_row
	void Add_Seat(Seat* s1);
	void Add_Seat(const string& Row_Name, int& num_seats);		//add_seat overload
	//accessor methods
    string Row_Name() const {return row_name;};
    int Number_of_Seats() const {return number_of_seats;};
    Seat* Get_Seat(int seat_nr);

    void Display() const;
};
