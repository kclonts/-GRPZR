#include <iostream>
#include "Venue_from_Xml.h"
#include "tinyxml.h"
#include <sstream>
#include "Address.h"
#include "Venue.h"
#include "Seat.h"
#include "Seat_Row.h"
using namespace std;

Address* Venue_from_Xml::Get_Address(TiXmlNode* address_node)
{
    string street;
    string city;
    string state;
    string buffer;
    int zip;
    
    
    TiXmlNode* street_node = address_node->FirstChild();
    assert(street_node != 0);
    street=street_node->FirstChild()->Value();


    TiXmlNode* city_node = street_node->NextSibling();
    assert(city_node != 0);
    city=city_node->FirstChild()->Value();


    TiXmlNode* state_node = city_node->NextSibling();
    assert(state_node != 0);
    state=state_node->FirstChild()->Value();


    TiXmlNode* zip_code = state_node->NextSibling();
    assert(zip_code != 0);
    buffer=zip_code->FirstChild()->Value();
    istringstream(buffer)>>zip;
    Address* addr=new Address(street,city,state,zip);
    
    return addr;
    
    
    
}

Seat* Venue_from_Xml::Get_Seat(TiXmlNode* seat_node,string rowName,Seat_Row* row)
{
    string buffer;
    int number;
    string section;
    Seat* s;
    
    TiXmlNode* number_node = seat_node->FirstChild("number");
    buffer=number_node->FirstChild()->Value();
    istringstream(buffer)>>number;
    
    s=new Seat(rowName,number,section);

    TiXmlNode* section_node = seat_node->FirstChild("section");
    section=section_node->FirstChild()->Value();
    
    
    s=new Seat(rowName,number,section);
    
    return s;
    
    
    
}

Seat_Row* Venue_from_Xml::Get_Seat_Row(TiXmlNode* seat_row_node, string rowName)
{
    TiXmlNode* name_node = seat_row_node->FirstChild("name");
    assert(name_node != 0);

    TiXmlNode* seat_node = seat_row_node->FirstChild("seat");
    Seat_Row* row=new Seat_Row(rowName);
    while (seat_node != 0)
    {
        row->addSeat(Get_Seat(seat_node,rowName,row));
        seat_node = seat_node->NextSibling();
        
    }
    return row;
}

void Venue_from_Xml::Get_Seats(TiXmlNode* seat_row_node, Venue* ven)
{
    while (seat_row_node != 0)
    {
        string n;
        TiXmlNode* rowNameTag= seat_row_node->FirstChild();
        assert(rowNameTag != 0);
        TiXmlNode* rowName= rowNameTag->FirstChild();
        assert(rowName != 0);
        n=rowName->Value();
        
    
        ven->Add_Row(Get_Seat_Row(seat_row_node,n));
        seat_row_node = seat_row_node->NextSibling();
    }
}



Venue* Venue_from_Xml::Get_Venue(TiXmlNode* venue_node)
{
    string name;
    Address* addr;
    Venue* v;
    
    
    TiXmlNode* name_node = venue_node->FirstChild();
    assert(name_node != 0);
    
    TiXmlNode* name_text_node = name_node->FirstChild();
    assert(name_text_node != 0);
    name=name_text_node->Value();
   

    TiXmlNode* address_node = name_node->NextSibling();
    assert(address_node != 0);
    

    addr=Get_Address(address_node);
    v=new Venue(name, *addr);
    
    

    TiXmlNode* seat_row_node = address_node->NextSibling();
    assert(seat_row_node != 0);
    Get_Seats(seat_row_node, v);
    return v;
}


